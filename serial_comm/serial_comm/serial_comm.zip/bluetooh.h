#pragma once
#include <stdio.h>
#include "serialcomm.h"
#include <iostream>

using namespace std;
int startflag = 0;

CSerialComm serialComm;

void bluetoothConnect(const char* _portNum);
void  bluetoothSend(int data);
void bluetoothRecv(void);
void bluetoothDisconnect(void);